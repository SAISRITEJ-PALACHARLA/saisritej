<?php
  /**
   * This script handles the email form submission.
   * Make sure to upload the "PHP Email Form" library to your server.
   * For more help: https://bootstrapmade.com/php-email-form/
   */

  // Replace this with your actual receiving email address
  $receiving_email_address = 'contact@example.com';

  // Ensure that the PHP Email Form library is available
  if( file_exists($php_email_form = '../assets/vendor/php-email-form/php-email-form.php' )) {
    include( $php_email_form );
  } else {
    die( 'Unable to load the "PHP Email Form" Library!');
  }

  // Create a new email form instance
  $contact = new PHP_Email_Form;
  $contact->ajax = true;

  // Set the recipient email address
  $contact->to = $receiving_email_address;

  // Set the email sender details
  $contact->from_name = $_POST['name'] ?? '';
  $contact->from_email = $_POST['email'] ?? '';
  $contact->subject = $_POST['subject'] ?? 'No subject provided';

  // Validate required fields
  if(empty($contact->from_name) || empty($contact->from_email) || empty($_POST['message'])) {
    echo json_encode(array('status' => 'error', 'message' => 'Please fill all the required fields.'));
    exit;
  }

  // Add your SMTP configuration if needed for secure email delivery
  /*
  $contact->smtp = array(
    'host' => 'smtp.example.com',
    'username' => 'your_smtp_username',
    'password' => 'your_smtp_password',
    'port' => '587', // or '465' for SSL
    'encryption' => 'tls' // or 'ssl'
  );
  */

  // Add email messages
  $contact->add_message($_POST['name'], 'From');
  $contact->add_message($_POST['email'], 'Email');
  $contact->add_message($_POST['message'], 'Message', 10);

  // Send the email and return the result
  if ($contact->send()) {
    echo json_encode(array('status' => 'success', 'message' => 'Your message has been sent. Thank you!'));
  } else {
    echo json_encode(array('status' => 'error', 'message' => 'Sorry, your message could not be sent. Please try again later.'));
  }
?>
